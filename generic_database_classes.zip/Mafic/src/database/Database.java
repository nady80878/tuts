/*
 * <code>Database</code> class includes generic methods to delete , insert, update, select
 * from any type of table  
 * uses a <code>Data</code> class as a container class
 * @auther Nady Shalaby 
 */

package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Database {

	private final static String DB_URL = "jdbc:mysql://localhost:3306/mafic";
	private final static String DB_USERNAME = "root";
	private final static String DB_PASSWORD = "";

	private static Database db = null;
	private Connection conn = null; // connection to the database
	ResultSet rs;
	String message = null;// message will be sent back to client

	private Database() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			conn = DriverManager
					.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
			// constructs SQL statement
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static Database getInstance() {
		if (db == null) {
			db = new Database();
		}
		return db;
	}

	public boolean insert(String table, Data columnsData) {
		String sql = String.format("INSERT INTO %s ( ", table);
		for(String str : columnsData.getColumnNames()){
			sql += String.format("%s, ", str);
		}
	    StringBuffer str = new StringBuffer(sql);
	    str.deleteCharAt(sql.length() - 2);
	    str.append(") VALUES ( ");
	    for(String s : columnsData.getColumnNames()){
			str.append("?, ");
		}
	    str.deleteCharAt(str.length() - 2);
	    str.append(")");
		try {
			PreparedStatement st = conn.prepareStatement(str.toString());
			int count = 1;
			for(String s : columnsData.getColumnNames()){
				if(columnsData.getIntVal(s) != null){
					st.setInt(count++, columnsData.getIntVal(s));
				}else if(columnsData.getDoubleVal(s) != null){
					st.setDouble(count++, columnsData.getDoubleVal(s));
				}else if(columnsData.getLongVal(s) != null){
					st.setLong(count++, columnsData.getLongVal(s));
				}else if(columnsData.getStreamVal(s) != null){
					st.setBinaryStream(count++, columnsData.getStreamVal(s));
				}else if(columnsData.getStringVal(s) != null){
					st.setString(count++, columnsData.getStringVal(s));
				}
			}
			System.out.println(str.toString());
			if(st.executeUpdate() > 0){
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return false;
	}

	public boolean update(String table, Data columnsData, String whereClause,
			Data whereData) {
		String sql = String.format("UPDATE %s SET ", table);
		for(String str : columnsData.getColumnNames()){
			sql += String.format("%s = ?, ", str);
		}
	    StringBuffer str = new StringBuffer(sql);
	    str.deleteCharAt(sql.length() - 2);
	    str.append(String.format(" WHERE %s ", whereClause));
		try {
			PreparedStatement st = conn.prepareStatement(str.toString());
			int count = 1;
			for(String s : columnsData.getColumnNames()){
				if(columnsData.getIntVal(s) != null){
					st.setInt(count++, columnsData.getIntVal(s));
				}else if(columnsData.getDoubleVal(s) != null){
					st.setDouble(count++, columnsData.getDoubleVal(s));
				}else if(columnsData.getLongVal(s) != null){
					st.setLong(count++, columnsData.getLongVal(s));
				}else if(columnsData.getStreamVal(s) != null){
					st.setBinaryStream(count++, columnsData.getStreamVal(s));
				}else if(columnsData.getStringVal(s) != null){
					st.setString(count++, columnsData.getStringVal(s));
				}			
			}
			if(whereData != null){
				for(String s : whereData.getColumnNames()){
					if(whereData.getIntVal(s) != null){
						st.setInt(count++, whereData.getIntVal(s));
					}else if(whereData.getDoubleVal(s) != null){
						st.setDouble(count++, whereData.getDoubleVal(s));
					}else if(whereData.getLongVal(s) != null){
						st.setLong(count++, whereData.getLongVal(s));
					}else if(whereData.getStreamVal(s) != null){
						st.setBinaryStream(count++, whereData.getStreamVal(s));
					}else if(whereData.getStringVal(s) != null){
						st.setString(count++, whereData.getStringVal(s));
					}		
				}
			}		
			System.out.println(str.toString());
			if(st.executeUpdate() > 0){
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			System.out.print(e);
		}
		return false;
	}

	public boolean delete(String table, String whereClause, Data whereData) {
		String sql = String.format("DELETE FROM %s ", table);
	    StringBuffer str = new StringBuffer(sql);
	    str.append(String.format(" WHERE %s ", whereClause));
		try {
			PreparedStatement st = conn.prepareStatement(str.toString());
			int count = 1;
			for(String s : whereData.getColumnNames()){
				if(whereData.getIntVal(s) != null){
					st.setInt(count++, whereData.getIntVal(s));
				}else if(whereData.getDoubleVal(s) != null){
					st.setDouble(count++, whereData.getDoubleVal(s));
				}else if(whereData.getLongVal(s) != null){
					st.setLong(count++, whereData.getLongVal(s));
				}else if(whereData.getStreamVal(s) != null){
					st.setBinaryStream(count++, whereData.getStreamVal(s));
				}else if(whereData.getStringVal(s) != null){
					st.setString(count++, whereData.getStringVal(s));
				}		
			}
			System.out.println(str.toString());
			if(st.executeUpdate() > 0){
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			System.out.print(e);
		}
		return false;
	}
	public ResultSet select(String table, String[] columnsNames, String whereClause,
			Data whereData) {
		String sql = "SELECT ";
		StringBuffer str ;
		if(columnsNames != null){
			for(String s : columnsNames){
				sql += String.format("%s, ", s);
			}
			 str = new StringBuffer(sql);
			 str.deleteCharAt(sql.length() - 2);
		}else{
			 str = new StringBuffer(sql);
			 str.append("*");
		}
		  
	    str.append(String.format(" FROM %s WHERE %s ", table , whereClause));
		try {
			PreparedStatement st = conn.prepareStatement(str.toString());
			if(whereData != null){
				int count = 1;
				for(String s : whereData.getColumnNames()){
					if(whereData.getIntVal(s) != null){
						st.setInt(count++, whereData.getIntVal(s));
					}else if(whereData.getDoubleVal(s) != null){
						st.setDouble(count++, whereData.getDoubleVal(s));
					}else if(whereData.getLongVal(s) != null){
						st.setLong(count++, whereData.getLongVal(s));
					}else if(whereData.getStreamVal(s) != null){
						st.setBinaryStream(count++, whereData.getStreamVal(s));
					}else if(whereData.getStringVal(s) != null){
						st.setString(count++, whereData.getStringVal(s));
					}		
				}
			}	
			System.out.println(str.toString());
			return st.executeQuery();
		} catch (Exception e) {
			System.out.print(e);
		}
		return null;
	}
}

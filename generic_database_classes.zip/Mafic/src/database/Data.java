package database;

import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Data {

	private Map<String,Integer> ints;
	private Map<String,Double> doubles;
	private Map<String,String> strings;
	private Map<String,InputStream> streams;
	private Map<String,Long> longs;
	private Set<String> columns;
	
	public Data() {
		ints = new HashMap<>();
		doubles = new HashMap<>();
		strings = new HashMap<>();
		streams = new HashMap<>();
		longs = new HashMap<>();
		columns = new HashSet<>();
	}

	public Integer getIntVal(String key) {
		return this.ints.get(key);
	}

	public void setIntVal(String key,int intVal) {
		this.columns.add(key);
		this.ints.put(key, intVal);
	}

	public Double getDoubleVal(String key) {
		return this.doubles.get(key);
	}

	public void setDoubleVal(String key,double doubleVal) {
		this.columns.add(key);
		this.doubles.put(key, doubleVal);
	}

	public String getStringVal(String key) {
		return this.strings.get(key);
	}

	public void setStringVal(String key,String stringVal) {
		this.columns.add(key);
		this.strings.put(key, stringVal);
	}

	public InputStream getStreamVal(String key) {
		return this.streams.get(key);
	}

	public void setStreamVal(String key,InputStream streamVal) {
		this.columns.add(key);
		this.streams.put(key, streamVal);
	}

	public Long getLongVal(String key) {
		return this.longs.get(key);
	}

	public void setLongVal(String key,long longVal) {
		this.columns.add(key);
		this.longs.put(key, longVal);
	}
	
	public String[] getColumnNames(){
		return this.columns.toArray(new String[this.columns.size()]);
	}
	
}
